<?php

namespace App\Http\Controllers;

use App\Models\GuzzlePost;
use Illuminate\Http\Request;
use \GuzzleHttp\Client;

class GuzzlePostController extends Controller
{
    // Store the data sent from the Guzzle Consumer
    public function store(Request $request)
    {
        $data = new GuzzlePost();
        $data->name=$request->get('name');
        $data->description = $request->get('description');
        $data->url = $request->get('url');
        $data->save();
        return response()->json('Successfully added');
    }

    // Retrieve data from the GuzzlePost
    public function index()
    {
        $data = GuzzlePost::all();
        return response()->json($data);
    }
}
